# Gibs_of_Gory

Ultraviolance for OpenXcom

## Credits

Death sprites by Brain_322
Scripting Help by Yankes


## Hidden Knowledge

In the script API there is 
```
RuleList.master
RuleList.current
```

For example the current sprite offset can be obtained by
`rules.getSpriteOffsetBigobs temp RuleList.current;`